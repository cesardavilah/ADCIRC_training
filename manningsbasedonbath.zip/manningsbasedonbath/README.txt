This is a simple program to assign mannings number based on water depths.

First step is to test that the program runs correctly. Simply locate the file 'manningsbasedonbath.exe' and execute. A pop up will appear showing a black screen and it will close after program has completed. You will see a 'fort.13' file that has been created. If the fort.13 file was created then continue with the guide.

###FILE DESCRIPTION###

The program takes two files as input:
-'fort.14': Standard fort.14 containing grid information (created by SMS)
-'levels': File containing the input for the program, here you will assign elevations and a manninngs n number.

You can find an example of the files in this folder. You can take a look at them by opening them with a text editor.

###HOW TO INPUT###

	The 'levels' file should contain pairs of values separated by a whitespace. In each pair the value on the left is the elevation (following fort.14 specifications  where a negative value is above geoid, and a positive value is below the geoid) and the right value is the mannings n number assigned. The program will read this file and assign the specified mannings n number to every node below the specified elevation (inclusive), please only use integers for elevations.
#EXAMPLE#
0 .9		All elevations <= 0 are assigned 0.9 mannings n value. 
250 .15		All elevations <= 250 and > 0 are assigned 0.15 mannings n value.
500 .3		.
3000 .02	.
10000 .001	.

Modify this levels input file as desired.

###HOW TO RUN###
	After correclty modifiying the input files, locate the file called 'manningsbasedonbath.exe' and double click. A pop up will appear showing a black screen and it will close after program has completed.

###OUTPUT###
	After a successful run of the program a 'fort.13' file would be created.

	NOTICE: The program doesn't assign a default value to the nodes not included in the 'levels' file, instead it defaults to 0.0200000 (open waters mannings n). If you want to assign a default value to the nodes not specified modify the 'fort.13' output file.

#EXAMPLE ON HOW TO ASSIGN DEFAULT VALUE# fort.13 file contents:

Spatial attributes description
59818
1
mannings_n_at_sea_floor
 m
 1
 0.0200000	<-- Default value, change this to change the default value of nodes not specified in the 'levels' file.